<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<script src="jscript/validation.js" type="text/javascript"></script>
<style type="text/css">

body{
  background:url('vote5.jpg') no-repeat center center fixed;
  background-size: cover;
}
#header_voter{  
  list-style-type: none;  
  margin: 0;  
  padding: 0px;  
  overflow: hidden;  
  background-color: #fcba03;  
}  
  
li {  
  float: left;  
}  
  
li a {  
  display: block;  
  color: black;  
 font-size:20px;  
  text-align: center;  
  padding: 10px 20px;  
  text-decoration: none;  
}  
.active{  
background-color: #d966ff;  
color: white;  
}  
li a:hover {  
  background-color: #39004d;  
  color: white;  
}  


</style>
</head>

<body bgcolor="#EBE9E9">
    <div id="header_voter">
<ul style="list-style-type:circle">
  <li><a href="voter.php">Home</a></li>
  <li><a href="lan_view.php">Vote Results</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="logout.php">Logout</a></li>
  <li><a href="change_pass.php">Change Password</a></li>
</ul></font> </div>
<!-- <marquee>Welcome To Online Voting System Coded By KISHOR KUMAR</marquee> -->
<!-- <center><font size='6' >
<a href="voter.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="lan_view.php">Vote Results</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="profile.php">Profile</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="logout.php">Logout</a>
&nbsp;&nbsp;|&nbsp;&nbsp;<a href="change_pass.php">Change Password</a>
</font></center>  -->
