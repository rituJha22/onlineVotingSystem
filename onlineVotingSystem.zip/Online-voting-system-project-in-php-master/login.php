


 <?php include "header.php"; 
if(!isset($_SESSION)) {
session_start();
}
if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}
?>
<br>
<div id="login">
<legend> <font color="white"><h3>Login for Voting </h3></font></legend> 


<?php global $nam; echo $nam; ?>
<?php global $error; echo $error; ?>


<font color=" #fcba03">
<form action="login_action.php" method="post" id="myform" >
	
Username : 
<div id="boxes">
<input type="text" name="username" value=""  > </div>
<br>
<br>
Password : 
<div id="boxes">
<input type="password" name="password" value=""  ></div>
<br>
<br>
<br>
<!-- <div class="button"> -->
<input  type="submit" id="button" name="login" value="Login" > 
<!-- </div> -->
</form></font>
</div>

<script type="text/javascript" > 
var frmvalidator = new Validator("myform");
frmvalidator.addValidation("username" , "req" , "Please Enter Username");
frmvalidator.addValidation("username", "maxlen=50");
frmvalidator.addValidation("password", "req" , "Please Enter Password");
</script>

<?php include "footer.php"; ?>
