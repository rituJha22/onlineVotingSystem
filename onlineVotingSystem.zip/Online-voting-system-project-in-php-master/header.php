


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting System</title>
<script src="jscript/validation.js" type="text/javascript"></script>
<style type="text/css">

body{
  background:url('vote5.jpg') no-repeat center center fixed;
  background-size: cover;
}
ul {  
  list-style-type: none;  
  margin: 0;  
  padding: 0px;  
  overflow: hidden;  
  background-color: #fcba03;  
}  
  
li {  
  float: left;  
}  
  
li a {  
  display: block;  
  color: black;  
 font-size:20px;  
  text-align: center;  
  padding: 10px 20px;  
  text-decoration: none;  
}  
.active{  
background-color: #d966ff;  
color: white;  
}  
li a:hover {  
  background-color: #39004d;  
  color: white;  
}  
#button{
  background-color: White; 
  border: 5px solid;
  border-color:#ffd700;
  color:black ;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  border-radius:10px;
  
}
#button:hover{
  background-color: #fcba03; 
  color:black ;  
}
#boxes{
  border-radius:5px;
  border: 2px solid;
  border-color:#ffd700;
  display: inline-block;

  
}
#registration{
  margin-left:950px;
  font-size: 26px;
}
#login{
  margin-left:950px;
  font-size: 32px;
}
/* Change the link color to #111 (black) on hover */


</style>
</head>
<body >
<!-- <marquee color="#ff00ff">Welcome To Online Voting System</marquee>
<center><font size='20' > 
         -->

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="register.php">Register</a></li>
  <li><a href="login.php">Login</a></li>
</ul> 
<!-- <a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="register.php">Register</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="login.php">Login</a></font></center> 
<br>
<br> -->