<html> 
<head>
<style type="text/css">

body {
background-color: #e5c685;
}
#voter{
    margin-left: 950px;
    font-size: 23px;
    color: #fcba03;
}
#boxes{
  border-radius:5px;
  border: 2px solid;
  border-color:#ffd700;
  display: inline-block;

  
}
#button{
  background-color: White; 
  border: 5px solid;
  border-color:#ffd700;
  color:black ;
  padding: 3px 17px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  border-radius:10px;
  
}
#button:hover{
  background-color: #fcba03; 
  color:black ;  
}

</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
</body>
</html>

<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";
include "header_voter.php"; 
?>
<br>
<br>
<div id="voter"><font color="white"><h2>Change Password</h2></font>
<h4 style="color:#e60808;"><?php global $nam; echo $nam;?> </h4> 
<?php global $error; echo $error;?>                  

<form action="change_pass_action.php" method="post" id="myform">
<b>Current Password:</b>
<input type="password" id="boxes" name="cpassword" value="" >
<br>
<br>
<b>New Password:</b>
<input type="password" id="boxes" name="npassword" value="" >
<br>
<br>
<b>Confirm New Password:</b>
<input type="password" id="boxes" name="cnpassword" value="" >
<br>
<br>
<br>
<input type="submit" id="button" name="cpass" value="UPDATE" >
</form></div>
<script type="text/javascript">
var frmvalidator = new Validator("myform"); 
frmvalidator.addValidation("cpassword","req","Please enter Current Password"); 
frmvalidator.addValidation("cpassword","maxlen=50");
frmvalidator.addValidation("npassword","req","Please enter New Password"); 
frmvalidator.addValidation("npassword","maxlen=50");
frmvalidator.addValidation("cnpassword","req","Please enter Confirm New Password"); 
frmvalidator.addValidation("cnpassword","maxlen=50");
</script>
<br>
<br>
<?php include "footer.php";?>
