

<script src='https://www.google.com/recaptcha/api.js'></script>
<?php include "header.php";
if(!isset($_SESSION)) {
session_start();
}
if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}
?>

<div id="registration">
<!-- <center> -->
<legend> <font color="white"><h2> Register </h2></font></legend> 
<?php global $nam; echo $nam; ?> 
<?php global $error; echo $error; ?>


<font size="6" color=" #fcba03">
<form action= "reg_action.php" method= "post" id="myform" >
<b>
Firstname:</b></b>
<div id="boxes">
<input type="text" name="firstname" value=""  /></div>
<br>
<br>

<b>
Lastname: </b>
<div id="boxes">
<input type="text" name="lastname" value="" /></div>
<br>
<br>
<b>Username:</b> 
<div id="boxes">
<input type="text" name="username" value="" /></div>
<br>
<br>
<b>Password: </b>
<div id="boxes">
<input type="password" name="password" value="" /></div>
<br>
<br>
<!-- <div class="g-recaptcha" data-sitekey="6LeD3hEUAAAAAKne6ua3iVmspK3AdilgB6dcjST0"></div> 
<br>
<br> -->
<!-- <div class="button"> -->
<b>
<input type="submit" id= "button" name="submit" value="Next" /></b>
<!-- </div> -->
</form>
</font>
<!-- </center> -->
</div>
<script type= "text/javascript" >
 var frmvalidator = new Validator("myform"); 
 frmvalidator.addValidation("firstname","req","Please enter student firstname"); 
 frmvalidator.addValidation("firstname","maxlen=50");
 frmvalidator.addValidation("lastname","req","Please enter student lastname"); 
 frmvalidator.addValidation("lastname","maxlen=50");
 frmvalidator.addValidation("username","req","Please enter student username"); 
 frmvalidator.addValidation("username","maxlen=50");
 frmvalidator.addValidation("password","req","Please enter student password"); 
 frmvalidator.addValidation("password","minlen=6","Password must not be less than 6 characters.");

</script>
<?php include "footer.php" ;?>
