
<html>
<head>
<style type="text/css">

body {
    background-color: #e5c685;
}
#voter{
    margin-left: 950px;
}
#button{
  background-color: White; 
  border: 5px solid;
  border-color:#ffd700;
  color:black ;
  padding: 12px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  border-radius:10px;
  
}
#button:hover{
  background-color: #fcba03; 
  color:black ;  
}

</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>


<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";
include "header_voter.php"; 
?>

<font color='#fcba03'><h2> Welcome <?php echo $_SESSION['SESS_NAME']; ?>,<br>Make a Vote</h2></font>
<br>
<br>
<div id="voter">
<form action="submit_vote.php" name="vote" method="post" id="myform" >
<font size='6' color='#fcba03'> Whom would you like to vote? <br>
<input type="radio" name="lan" value="BJP">  BJP<br>
<input type="radio" name="lan" value="CONGRESS">CONGRESS<br>
<input type="radio" name="lan" value="AAP">   AAP<br>
<input type="radio" name="lan" value="NOTA">  NOTA<br>
<input type="radio" name="lan" value="INDL">  INLD<br>
</font><br>
<?php global $msg; echo $msg; ?>
<?php global $error; echo $error; ?>
 <input type="submit" id="button" value="Submit Vote" name="submit" />
</form></div>
<?php include "footer.php";?>
</body>
</html>