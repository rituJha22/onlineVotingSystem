<html> 
<head>
<style type="text/css">

body {
background-color: #e5c685;
}
#profile{
    margin-left:950px;
    
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>


<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";
include "header_voter.php";
include "connection.php";
?>
<div id="profile">
<font color='#fcba03'><h2> Welcome <?php echo $_SESSION['SESS_NAME']; ?> </h2></font>
<font size='6' color='#fcba03'>
<?php
$username = $_SESSION['SESS_NAME'];
$query = 'SELECT status FROM voters WHERE username="'.$_SESSION['SESS_NAME'].'" AND status = "VOTED"';
if ($result = mysqli_query($con,$query)) {
if (mysqli_num_rows($result) > 0) {
$sql = mysqli_query($con, 'SELECT voted from voters WHERE username="'.$_SESSION['SESS_NAME'].'"');
$row = mysqli_fetch_assoc($sql);
        echo "You have voted for: " . " " . $row['voted'];
    } else {
        echo "You have not voted yet. Please submit your vote!";
    }
}
?></font></div>
<?php include "footer.php";?>
</body>
</html>